package com.example.xlo.data

import androidx.room.Entity
import androidx.room.PrimaryKey

// data/CartItem.java
@Entity(tableName = "cart_items")
class CartItem(// Foreign key (link to ProductEntity)
    @JvmField var productId: Int,
    @JvmField var quantity: Int, // Optional: store price snapshot in case product price changes
    @JvmField var unitPrice: Int
) {
    @JvmField
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

    init {
        this.unitPrice = unitPrice
    }
}
