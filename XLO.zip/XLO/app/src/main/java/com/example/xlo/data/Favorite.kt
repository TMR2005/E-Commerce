// com.example.xlo.data.Favorite.java
package com.example.xlo.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class Favorite(@JvmField @field:PrimaryKey var productId: Int)
