package com.example.xlo

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.xlo.FavoriteAdapter.FavoriteViewHolder
import com.example.xlo.data.AppDatabase
import com.example.xlo.data.Product

class FavoriteAdapter(
    private val context: Context,
    private val favoriteList: MutableList<Product>,
    private val db: AppDatabase
) :
    RecyclerView.Adapter<FavoriteViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FavoriteViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_favorite, parent, false)
        return FavoriteViewHolder(view)
    }

    override fun onBindViewHolder(holder: FavoriteViewHolder, position: Int) {
        val product = favoriteList[position]

        // You can load imageUrl here, using Glide/Picasso or just dummy for now
        holder.imageView.setImageResource(R.drawable.ic_launcher_background)

        holder.title.text = product.title
        holder.price.text = "₹ " + product.price
        holder.brand.text = product.brand

        holder.removeFavoriteBtn.setOnClickListener { v: View? ->
            // Remove from favorites DB
            db.favoriteDao()?.removeByProductId(product.id)

            // Remove from list and notify adapter
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                favoriteList.removeAt(pos)
                notifyItemRemoved(pos)
                Toast.makeText(
                    context,
                    product.title + " removed from favorites",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }

    override fun getItemCount(): Int {
        return favoriteList.size
    }

    class FavoriteViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imageView: ImageView =
            itemView.findViewById(R.id.favorite_product_image)
        var title: TextView =
            itemView.findViewById(R.id.favorite_product_title)
        var price: TextView =
            itemView.findViewById(R.id.favorite_product_price)
        var brand: TextView =
            itemView.findViewById(R.id.favorite_product_brand)
        var removeFavoriteBtn: ImageView =
            itemView.findViewById(R.id.button_remove_favorite)
    }
}
