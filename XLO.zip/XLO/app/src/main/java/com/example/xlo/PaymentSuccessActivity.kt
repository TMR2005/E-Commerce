package com.example.xlo

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import com.example.xlo.data.AppDatabase
import com.example.xlo.data.Order

class PaymentSuccessActivity : AppCompatActivity() {

    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_payment_success)

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "xlo-db"
        ).build()

        // Get order data safely from Intent extras
        val orderSummary = intent.getStringExtra("order_summary") ?: ""
        val totalAmount = intent.getIntExtra("total_amount", 0)
        val orderDate = intent.getStringExtra("order_date") ?: ""

        // Insert order into DB on a background thread
        Thread {
            val newOrder = Order(orderSummary, totalAmount, orderDate)
            db.orderDao()?.insertOrder(newOrder)
        }.start()

        // After delay, navigate to MainActivity (home)
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            finish()
        }, DELAY_MILLIS)
    }

    companion object {
        private const val DELAY_MILLIS: Long = 2000 // 2 seconds delay
    }
}
