package com.example.xlo

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.example.xlo.ProductAdapter.ProductViewHolder
import com.example.xlo.data.AppDatabase
import com.example.xlo.data.CartItem
import com.example.xlo.data.Favorite
import com.example.xlo.data.Product

class ProductAdapter(
    private val context: Context, private var productList: List<Product>, // database instance
    private val db: AppDatabase
) :
    RecyclerView.Adapter<ProductViewHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProductViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_product, parent, false)
        return ProductViewHolder(view)
    }

    override fun onBindViewHolder(holder: ProductViewHolder, position: Int) {
        val product = productList[position]

        // Set dummy image since imageUrl is not yet handled
        holder.imageView.setImageResource(R.drawable.ic_launcher_background)

        holder.title.text = product.title
        holder.price.text = "₹ " + product.price
        holder.year.text = product.year.toString()
        holder.brand.text = product.brand
        holder.city.text = product.city
        holder.eco.text = "Eco: " + product.ecoScore + "/100"
        holder.date.text = product.date

        // Set click listener on Add to Cart button
        holder.addToCartBtn.setOnClickListener { v: View? ->
            // Create CartItem with quantity 1 (you can expand this later)
            val cartItem = CartItem(product.id, 1, product.price)

            // Insert into DB
            db.cartDao()?.insertToCart(cartItem)
            Toast.makeText(context, product.title + " added to cart", Toast.LENGTH_SHORT).show()
        }
        holder.favoriteButton.setOnClickListener { v: View? ->
            try {
                val isFav = db.favoriteDao()?.isFavorite(product.id)
                if (!isFav!!) {
                    // Add to favorites
                    db.favoriteDao()?.addToFavorites(Favorite(product.id))
                    Toast.makeText(context, "Added to favorites", Toast.LENGTH_SHORT).show()
                    // Optionally update the favorite icon to "filled" here
                } else {
                    // Remove from favorites
                    db.favoriteDao()?.removeByProductId(product.id)
                    Toast.makeText(context, "Removed from favorites", Toast.LENGTH_SHORT).show()
                    // Optionally update the favorite icon to "empty" here
                }
            } catch (e: Exception) {
                Toast.makeText(context, "Error updating favorites: " + e.message, Toast.LENGTH_LONG)
                    .show()
                e.printStackTrace()
            }
        }
    }

    override fun getItemCount(): Int {
        return productList.size
    }

    fun setProductList(products: List<Product>) {
        this.productList = products
        notifyDataSetChanged()
    }

    class ProductViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var imageView: ImageView =
            itemView.findViewById(R.id.product_image)
        var title: TextView =
            itemView.findViewById(R.id.product_title)
        var price: TextView =
            itemView.findViewById(R.id.product_price)
        var year: TextView =
            itemView.findViewById(R.id.product_year)
        var brand: TextView =
            itemView.findViewById(R.id.product_brand)
        var city: TextView =
            itemView.findViewById(R.id.product_city)
        var eco: TextView =
            itemView.findViewById(R.id.product_eco)
        var date: TextView =
            itemView.findViewById(R.id.product_date)
        var addToCartBtn: Button =
            itemView.findViewById(R.id.button_add_to_cart)
        var favoriteButton: ImageView =
            itemView.findViewById(R.id.button_favorite)
    }
}
