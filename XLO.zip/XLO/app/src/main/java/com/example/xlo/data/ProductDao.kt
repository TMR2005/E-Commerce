// data/ProductDao.java
package com.example.xlo.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

@Dao
interface ProductDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertProduct(product: Product?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertAll(products: List<Product?>?)

    @get:Query("SELECT * FROM Product")
    val allProducts: List<Product?>?

    @Query("SELECT * FROM Product WHERE id = :id")
    fun getProductById(id: Int): Product?

    @Query("SELECT * FROM Product WHERE price BETWEEN :minPrice AND :maxPrice")
    fun getProductsByPriceRange(minPrice: Int, maxPrice: Int): List<Product?>?
}
