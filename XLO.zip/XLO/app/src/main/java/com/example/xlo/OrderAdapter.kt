package com.example.xlo

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.xlo.data.Order

class OrderAdapter(
    private val context: Context,
    private var orders: MutableList<Order>
) : RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    // Fix: Accept non-nullable MutableList<Order>, avoid nullable Order?
    fun setOrders(orders: MutableList<Order>) {
        this.orders = orders
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_order, parent, false)
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orders[position]
        // Bind data safely assuming order properties are non-null
        holder.summary.text = order.productSummary
        holder.totalAmount.text = "₹ ${order.totalAmount}"
        holder.date.text = order.date
    }

    override fun getItemCount(): Int = orders.size

    class OrderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val summary: TextView = itemView.findViewById(R.id.order_summary)
        val totalAmount: TextView = itemView.findViewById(R.id.order_total)
        val date: TextView = itemView.findViewById(R.id.order_date)
    }
}
