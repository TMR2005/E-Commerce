package com.example.xlo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.example.xlo.data.AppDatabase
import com.example.xlo.data.Product

class FavoritesActivity : AppCompatActivity() {

    private lateinit var favoritesRecycler: RecyclerView
    private lateinit var db: AppDatabase
    private lateinit var adapter: FavoriteAdapter
    private val favoriteProducts = mutableListOf<Product>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_favorites)

        favoritesRecycler = findViewById(R.id.favorites_recycler)
        favoritesRecycler.layoutManager = LinearLayoutManager(this)

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "xlo-db"
        )
            .allowMainThreadQueries() // For demo only; avoid in production
            .build()

        adapter = FavoriteAdapter(this, favoriteProducts, db)
        favoritesRecycler.adapter = adapter

        loadFavorites()
    }

    override fun onResume() {
        super.onResume()
        loadFavorites()
    }

    private fun loadFavorites() {
        val favoriteEntries = db.favoriteDao()?.allFavorites ?: emptyList()

        favoriteProducts.clear()
        favoriteEntries.forEach { fav ->
            val product = fav?.let { db.productDao()?.getProductById(it.productId) }
            if (product != null) {
                favoriteProducts.add(product)
            }
        }
        adapter.notifyDataSetChanged()
    }
}
