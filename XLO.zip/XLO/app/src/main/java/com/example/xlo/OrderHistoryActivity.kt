package com.example.xlo

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.example.xlo.data.AppDatabase
import com.example.xlo.data.Order

class OrderHistoryActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var orderAdapter: OrderAdapter
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_order_history)

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java, "xlo-db"
        )
            .allowMainThreadQueries() // For demo only; avoid in production
            .build()

        recyclerView = findViewById(R.id.order_recycler)
        recyclerView.layoutManager = LinearLayoutManager(this)

        orderAdapter = OrderAdapter(this, mutableListOf())
        recyclerView.adapter = orderAdapter

        loadOrders()
    }

    private fun loadOrders() {
        val orders: List<Order?> = db.orderDao()?.allOrders ?: emptyList()
        orderAdapter.setOrders(orders.filterNotNull().toMutableList())
    }

}
