package com.example.xlo

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.xlo.CartAdapter.CartViewHolder
import com.example.xlo.data.AppDatabase
import com.example.xlo.data.CartItem

class CartAdapter(
    var context: Context,
    var cartItems: MutableList<CartItem>,
    var db: AppDatabase,
    var cartUpdatedListener: OnCartUpdatedListener?
) :
    RecyclerView.Adapter<CartViewHolder>() {
    interface OnCartUpdatedListener {
        fun onCartUpdated()
    }

    fun updateCartItems(cartItems: MutableList<CartItem>) {
        this.cartItems = cartItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.item_cart, parent, false)
        return CartViewHolder(view)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        val item = cartItems[position]
        val product = db.productDao()?.getProductById(item.productId)

        if (product != null) {
            holder.title.text = product.title
        }
        holder.qty.text = "Qty: " + item.quantity
        holder.price.text = "₹ " + (item.unitPrice * item.quantity)

        holder.removeBtn.setOnClickListener { v: View? ->
            val pos = holder.adapterPosition
            if (pos != RecyclerView.NO_POSITION) {
                // Remove from DB
                db.cartDao()?.deleteItem(item.productId)

                // Remove from list
                cartItems.removeAt(pos)

                // Notify adapter
                notifyItemRemoved(pos)
                notifyItemRangeChanged(pos, cartItems.size)

                // Callback to update total
                if (cartUpdatedListener != null) {
                    cartUpdatedListener!!.onCartUpdated()
                }
            }
        }
    }

    override fun getItemCount(): Int {
        return cartItems.size
    }

    class CartViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var title: TextView =
            itemView.findViewById(R.id.cart_item_title)
        var qty: TextView =
            itemView.findViewById(R.id.cart_item_quantity)
        var price: TextView =
            itemView.findViewById(R.id.cart_item_price)
        var removeBtn: Button =
            itemView.findViewById(R.id.button_remove)
    }
}
