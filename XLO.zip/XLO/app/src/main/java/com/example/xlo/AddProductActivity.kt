package com.example.xlo

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.room.Room
import com.example.xlo.data.AppDatabase
import com.example.xlo.data.Product
import com.example.xlo.databinding.ActivityAddProductBinding

class AddProductActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAddProductBinding
    private lateinit var db: AppDatabase

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAddProductBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "xlo-db"
        ).allowMainThreadQueries().build()

        binding.buttonAddProduct.setOnClickListener {
            addProduct()
        }
    }

    private fun addProduct() {
        val title = binding.editTextTitle.text.toString().trim()
        val priceStr = binding.editTextPrice.text.toString().trim()
        val yearStr = binding.editTextYear.text.toString().trim()
        val brand = binding.editTextBrand.text.toString().trim()
        val city = binding.editTextCity.text.toString().trim()
        val ecoScoreStr = binding.editTextEcoScore.text.toString().trim()
        val date = binding.editTextDate.text.toString().trim()
        val imageUrl = binding.editTextImageUrl.text.toString().trim()

        if (title.isEmpty() || priceStr.isEmpty() || yearStr.isEmpty() ||
            brand.isEmpty() || city.isEmpty() || ecoScoreStr.isEmpty() || date.isEmpty()
        ) {
            Toast.makeText(this, "Please fill all required fields", Toast.LENGTH_SHORT).show()
            return
        }

        val price: Int
        val year: Int
        val ecoScore: Int
        try {
            price = priceStr.toInt()
            year = yearStr.toInt()
            ecoScore = ecoScoreStr.toInt()
        } catch (e: NumberFormatException) {
            Toast.makeText(
                this,
                "Please enter valid numbers for price, year, and eco score",
                Toast.LENGTH_SHORT
            ).show()
            return
        }

        val product = Product().apply {
            this.title = title
            this.price = price
            this.year = year
            this.brand = brand
            this.city = city
            this.ecoScore = ecoScore
            this.date = date
            this.imageUrl = imageUrl
        }


        db.productDao()?.insertProduct(product)
        Toast.makeText(this, "Product added successfully", Toast.LENGTH_SHORT).show()
        finish()
    }
}
