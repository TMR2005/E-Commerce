package com.example.xlo.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query

// data/CartDao.java
@Dao
interface CartDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    fun insertToCart(item: CartItem?)

    @get:Query("SELECT * FROM cart_items")
    val cartItems: List<CartItem?>?

    @Query("DELETE FROM cart_items WHERE id = :id")
    fun deleteItemById(id: Int)

    @Query("DELETE FROM cart_items")
    fun clearCart()

    @get:Query("SELECT SUM(quantity * unitPrice) FROM cart_items")
    val totalCartPrice: Int

    @Query("DELETE FROM cart_items WHERE productId = :productId")
    fun deleteItem(productId: Int)
}
