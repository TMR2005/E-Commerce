package com.example.xlo.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

// data/OrderDao.java
@Dao
interface OrderDao {
    @Insert
    fun insertOrder(order: Order?)

    @get:Query("SELECT * FROM orders ORDER BY id DESC")
    val allOrders: List<Order?>?
}
