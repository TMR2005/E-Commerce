package com.example.xlo.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
class Product {
    @JvmField
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0

    @JvmField
    var title: String? = null
    @JvmField
    var price: Int = 0
    @JvmField
    var year: Int = 0
    @JvmField
    var brand: String? = null
    @JvmField
    var city: String? = null
    @JvmField
    var ecoScore: Int = 0
    @JvmField
    var date: String? = null
    @JvmField
    var imageUrl: String? = null
}
