package com.example.xlo.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "orders")
class Order(@JvmField var productSummary: String, @JvmField var totalAmount: Int, @JvmField var date: String) {
    @JvmField
    @PrimaryKey(autoGenerate = true)
    var id: Int = 0
}
