package com.example.xlo

import android.content.DialogInterface
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.room.Room
import com.example.xlo.data.AppDatabase
import com.example.xlo.data.Product

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: ProductAdapter
    private lateinit var db: AppDatabase
    private var productList: List<Product> = listOf()
    private lateinit var buttonFavorites: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        db = Room.databaseBuilder(
            applicationContext,
            AppDatabase::class.java,
            "xlo-db"
        )
            .allowMainThreadQueries() // For testing only, avoid on production
            .build()

        recyclerView = findViewById(R.id.product_recycler)
        recyclerView.layoutManager = LinearLayoutManager(this)

        productList = db.productDao()?.allProducts as List<Product>
        adapter = ProductAdapter(this, productList, db)
        recyclerView.adapter = adapter

        findViewById<Button>(R.id.button_add_product).setOnClickListener {
            startActivity(Intent(this, AddProductActivity::class.java))
        }

        findViewById<Button>(R.id.button_open_cart).setOnClickListener {
            startActivity(Intent(this, CartActivity::class.java))
        }

        findViewById<Button>(R.id.button_view_orders).setOnClickListener {
            startActivity(Intent(this, OrderHistoryActivity::class.java))
        }

        buttonFavorites = findViewById(R.id.button_view_favorites)
        buttonFavorites.setOnClickListener {
            startActivity(Intent(this, FavoritesActivity::class.java))
        }

        findViewById<Button>(R.id.button_filter).setOnClickListener {
            showPriceFilterDialog()
        }

        findViewById<Button>(R.id.button_reset_filters).setOnClickListener {
            productList = db.productDao()!!.allProducts as List<Product>
            adapter.setProductList(productList)
        }

        insertSampleProducts() // Optionally insert sample data on first run
    }

    override fun onResume() {
        super.onResume()
        // Reload products on resume in case of changes
        productList = db.productDao()?.allProducts?.filterNotNull() ?: emptyList()
        adapter.setProductList(productList)
    }

    private fun insertSampleProducts() {
        if (db.productDao()?.allProducts?.isEmpty() == true) {
            val p1 = Product().apply {
                title = "iPhone 14"
                price = 65000
                year = 2022
                brand = "Apple"
                city = "Bengaluru"
                ecoScore = 82
                date = "Today"
                imageUrl = ""
            }
            db.productDao()?.insertProduct(p1)
        }
    }

    private fun showPriceFilterDialog() {
        val builder = AlertDialog.Builder(this)
        builder.setTitle("Filter by Price")

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 40, 50, 10)
        }

        val minPriceInput = EditText(this).apply {
            hint = "Min Price"
            inputType = InputType.TYPE_CLASS_NUMBER
        }

        val maxPriceInput = EditText(this).apply {
            hint = "Max Price"
            inputType = InputType.TYPE_CLASS_NUMBER
        }

        layout.addView(minPriceInput)
        layout.addView(maxPriceInput)
        builder.setView(layout)

        builder.setPositiveButton("Apply") { _, _ ->
            val minStr = minPriceInput.text.toString().trim()
            val maxStr = maxPriceInput.text.toString().trim()

            var minPrice = 0
            var maxPrice = Int.MAX_VALUE

            try {
                if (minStr.isNotEmpty()) {
                    minPrice = minStr.toInt().takeIf { it >= 0 } ?: throw NumberFormatException()
                }
                if (maxStr.isNotEmpty()) {
                    maxPrice = maxStr.toInt().takeIf { it >= 0 } ?: throw NumberFormatException()
                }
            } catch (e: NumberFormatException) {
                Toast.makeText(this, "Please enter valid positive numbers", Toast.LENGTH_SHORT).show()
                return@setPositiveButton
            }

            if (minPrice > maxPrice) {
                Toast.makeText(this, "Min price cannot be greater than max price", Toast.LENGTH_SHORT).show()
                return@setPositiveButton
            }

            val filteredList = productList.filter { it.price in minPrice..maxPrice }

            if (filteredList.isEmpty()) {
                Toast.makeText(this, "No products found in this price range", Toast.LENGTH_SHORT).show()
            }
            adapter.setProductList(filteredList)
        }

        builder.setNegativeButton("Cancel") { dialog, _ -> dialog.dismiss() }
        builder.show()
    }
}
