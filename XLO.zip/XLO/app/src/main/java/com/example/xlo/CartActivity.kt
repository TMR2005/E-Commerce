package com.example.xlo

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.xlo.data.AppDatabase
import com.example.xlo.data.CartItem
import com.example.xlo.data.Order
import com.example.xlo.databinding.ActivityCartBinding
import java.text.SimpleDateFormat
import java.util.*

class CartActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCartBinding
    private lateinit var db: AppDatabase
    private lateinit var adapter: CartAdapter
    private var cartItems: MutableList<CartItem> = mutableListOf()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)

        db = AppDatabase.getInstance(applicationContext)

        cartItems = db.cartDao()?.cartItems.orEmpty().filterNotNull().toMutableList()

        adapter = CartAdapter(this, cartItems, db, object : CartAdapter.OnCartUpdatedListener {
            override fun onCartUpdated() {
                cartItems = db.cartDao()?.cartItems.orEmpty().filterNotNull().toMutableList()
                adapter.updateCartItems(cartItems)
                updateTotal()
            }
        })




        binding.cartRecycler.layoutManager = LinearLayoutManager(this)
        binding.cartRecycler.adapter = adapter

        updateTotal()

        binding.buttonCheckout.setOnClickListener {
            val total = calculateTotal()
            val summary = buildProductSummary()
            val date = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date())

            val order = Order(summary, total, date)
            db.orderDao()?.insertOrder(order)

            db.cartDao()?.clearCart()
            cartItems = db.cartDao()?.cartItems?.filterNotNull()?.toMutableList() ?: mutableListOf()

            adapter.updateCartItems(cartItems)
            updateTotal()

            Intent(this, PaymentSuccessActivity::class.java).apply {
                putExtra("order_summary", summary)
                putExtra("total_amount", total)
                putExtra("order_date", date)
                startActivity(this)
            }
        }
    }

    private fun calculateTotal(): Int {
        return cartItems.sumOf { it.quantity * it.unitPrice }
    }

    private fun updateTotal() {
        val total = calculateTotal()
        if (cartItems.isEmpty()) {
            binding.emptyText.visibility = View.VISIBLE
            binding.cartRecycler.visibility = View.GONE
            binding.buttonCheckout.isEnabled = false
            binding.totalText.text = "Total: ₹ 0"
        } else {
            binding.emptyText.visibility = View.GONE
            binding.cartRecycler.visibility = View.VISIBLE
            binding.buttonCheckout.isEnabled = true
            binding.totalText.text = "Total: ₹ $total"
        }
    }

    private fun buildProductSummary(): String {
        return cartItems.joinToString(", ") { item ->
            val product = db.productDao()?.getProductById(item.productId)
            "${product?.title} x${item.quantity}"
        }
    }
}
