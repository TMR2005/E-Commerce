// com.example.xlo.data.FavoriteDao.java
package com.example.xlo.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query

@Dao
interface FavoriteDao {
    @Insert
    fun addToFavorites(favorite: Favorite?)

    @Delete
    fun removeFromFavorites(favorite: Favorite?)

    @Query("DELETE FROM Favorite WHERE productId = :productId")
    fun removeByProductId(productId: Int)

    @get:Query("SELECT * FROM Favorite")
    val allFavorites: List<Favorite?>?

    @Query("SELECT EXISTS(SELECT 1 FROM Favorite WHERE productId = :productId)")
    fun isFavorite(productId: Int): Boolean
}
